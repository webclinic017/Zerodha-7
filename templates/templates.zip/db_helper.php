<?php
 
$conn= mysqli_connect("localhost", "etech1m4_travDB","Travel!@#123@@","etech1m4_travel_within_DB");

if(!$conn)
{
	
	echo "connectivity error";
	
}

?>

